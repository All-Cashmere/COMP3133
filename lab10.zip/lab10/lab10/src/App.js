import React, { Component } from 'react';
import logo from './logo.svg';
import { BrowserRouter, Route, Switch, Link } from "react-router-dom";
import './App.css';
import Home from "./components/Home";
import About from "./components/About";
import Contact from "./components/Contact";
import Error from "./components/Error";


class App extends Component {
  render() {
    return (
      <BrowserRouter>
      <div>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/error">Error</Link>
          </li>

        </ul>
      <Switch>
        <Route path="/" component={Home} exact />
        <Route path="/contact" component={Contact} />
        <Route path="/about" component={About} />
        <Route path="/error" component={Error} />
      </Switch>
      </div>
      </BrowserRouter>
  
    );
  }
}

export default App;
