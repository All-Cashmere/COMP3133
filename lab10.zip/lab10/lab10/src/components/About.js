import React from "react"
const About = () => {
    return (
      <div>
        <p>about</p>
      </div>
    );
  }
  
  export default About;