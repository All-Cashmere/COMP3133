import React from "react"
const Home = () => {
    return (
      <div>
        <p>home</p>
      </div>
    );
  }
  
  export default Home;