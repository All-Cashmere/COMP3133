import React from "react"
const Contact = () => {
    return (
      <div>
        <p>contact</p>
      </div>
    );
  }
  
  export default Contact;