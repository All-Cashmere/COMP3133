import React from "react"
const Error = () => {
    return (
      <div>
        <p>err</p>
      </div>
    );
  }
  
  export default Error;